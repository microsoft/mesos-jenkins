#
# This is just a test script used to validate Mesos Fetcher
#

exit 0
